from flask import  render_template, url_for, flash, redirect, request,jsonify
from projet.forms import FormRegistration,LoginForm, PostForm, UpdateForm
from projet import app, db, bcrypt
from flask_login import login_user, logout_user, current_user, login_required
import secrets
import os


from projet.model import User, Post
@app.route("/")
@app.route("/home")
def home():
    if not current_user.is_authenticated:
        return redirect(url_for('login'))
    posts=Post.query.all()
    return render_template("home.html", posts=posts)
@app.route("/cv")
@login_required
def moncv():
    return render_template("about.html")
@app.route("/about")
@login_required
def about():
    return render_template("about.html")
@app.route("/registration", methods=['GET', 'POST'])
def registration():
    form=FormRegistration()
    if form.validate_on_submit(): 
        hashed_password=bcrypt.generate_password_hash(form.password.data).decode('utf-8')
        user=User(username=form.username.data, mail=form.mail.data, password=hashed_password)
        db.session.add(user)
        db.session.commit()
        flash(f'Compte de {form.username.data} crée', 'success')
        return redirect(url_for('login'))
    return render_template("registration.html",title='Souscription', form=form)
@app.route("/login", methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('home'))
    form=LoginForm()
    if form.validate_on_submit(): 
        user=User.query.filter_by(mail=form.mail.data).first()
        if user and bcrypt.check_password_hash(user.password, form.password.data):
            login_user(user, remember=form.remember.data)
            next_page=request.args.get('next')
            return redirect(next_page) if next_page else redirect(url_for('home'))
        else:
            flash(f'Mot de passe ou mail incorrect','danger')
    return render_template("login.html", title='Connexion', form=form)
@app.route("/logout")
def logout():
    logout_user()
    return redirect(url_for('home'))
def savePhoto(photo):
    random_hex=secrets.token_hex(8)
    _,f_ext=os.path.splitext(photo.filename)
    photo_fn==random_hex+f_ext
    photo_path=os.path.join(app.root_path, 'static/images/profil', photo_fn)
    photo.save(photo_path)
    return photo_fn

@app.route("/profil", methods=['GET', 'POST'])
@login_required
def profil():
    form=UpdateForm()
    image_profile=url_for('static',filename='images/profil/'+current_user.image)
    if form.validate_on_submit():
        current_user.username=form.username.data
        current_user.mail=form.mail.data
        db.session.commit()
        flash('Le compte a été mise à jour')
        return redirect(url_for('profil'))
    elif request.method=="GET":
        form.username.data=current_user.username
        form.mail.data=current_user.mail
    return render_template('profil.html', title='Profile', image=image_profile, form=form)
@app.route("/create/new", methods=['GET', 'POST'])
@login_required
def new_post():
    form=PostForm()
    if form.validate_on_submit(): 
        post=Post(title=form.title.data+"CHIF", content=form.content.data, user=current_user)
        db.session.add(post)
        db.session.commit()
        flash(f'Votre poste a été crée avec succes', 'success')
        return redirect(url_for('home'))
    return render_template('createpost.html', title='Créer un post', form=form)
db.create_all()
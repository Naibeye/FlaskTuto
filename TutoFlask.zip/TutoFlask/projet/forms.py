from flask_wtf import FlaskForm
from flask_wtf.file import FileField, FileAllowed
from wtforms import StringField, PasswordField, SubmitField, BooleanField, TextAreaField
from wtforms.validators import DataRequired, Email, Length, EqualTo, ValidationError
from projet.model import User
from flask_login import current_user

class FormRegistration(FlaskForm):
    username=StringField('Nom', validators=[DataRequired(),Length(min=2, max=20)])
    mail=StringField('Email', validators=[DataRequired(),Email()])
    password=PasswordField('Mot de passe', validators=[DataRequired()])
    confirm_pass=PasswordField('Confirmer mot de passe',validators=[DataRequired(), EqualTo('password')]) 
    submit=SubmitField('Valider')
    def validate_username(self, username):
        user=User.query.filter_by(username=username.data).first()
        if user:
            raise ValidationError('Ce nom utilisateur a été déja choisi.')
    def validate_mail(self, mail):
        user=User.query.filter_by(mail=mail.data).first()
        if user:
            raise ValidationError('Ce mail est déja utilisée')
class LoginForm(FlaskForm):
    mail=StringField('Email', validators=[DataRequired(),Email()])
    password=PasswordField('Mot de passe', validators=[DataRequired()])
    remember=BooleanField('Me rappeller')
    submit=SubmitField('Valider')
class PostForm(FlaskForm):
    title=StringField('Title', validators=[DataRequired()])
    content=TextAreaField('content', validators=[DataRequired()])
    submit=SubmitField('Create')
class UpdateForm(FlaskForm):
    username=StringField('Nom', validators=[DataRequired(),Length(min=2, max=20)])
    mail=StringField('Email', validators=[DataRequired(),Email()])
    photo=FileField('Avatar', validators=[FileAllowed(["jpg","png"])])
    submit=SubmitField('Update')
    def validate_username(self, username):
        if user.username!=current_user.username:
            user=User.query.filter_by(username=username.data).first()
            if user:
                raise ValidationError('Ce nom utilisateur a été déja choisi.')
    def validate_mail(self, mail):
        if user.mail!=current_user.mail:
            user=User.query.filter_by(mail=mail.data).first()
            if user:
                raise ValidationError('Ce mail est déja utilisée')